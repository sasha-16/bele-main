package com.flp.pms.view;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean flag=false;
		String productId=request.getParameter("prodId");
		System.out.println(Integer.parseInt(productId));
		IProductService iProductService=new ProductServiceImpl();
		 flag=iProductService.deleteProduct(Integer.parseInt(productId));
		if (flag){
			response.sendRedirect("pages/successdelete.html");
		}else
			response.sendRedirect("pages/error.html");
		
	}

}
